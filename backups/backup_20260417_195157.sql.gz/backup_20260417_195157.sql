--
-- PostgreSQL database dump
--

\restrict 2bzgTDB9UyjbrfT5zuC9qaK7xv1dzCx8VPgLxQy9ns728PZ0QNAOjsocFIbIyfw

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat_admins; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.chat_admins (
    id bigint NOT NULL,
    chat_id bigint,
    user_id bigint,
    created_at timestamp with time zone
);


ALTER TABLE public.chat_admins OWNER TO maxbot;

--
-- Name: chat_admins_id_seq; Type: SEQUENCE; Schema: public; Owner: maxbot
--

CREATE SEQUENCE public.chat_admins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chat_admins_id_seq OWNER TO maxbot;

--
-- Name: chat_admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maxbot
--

ALTER SEQUENCE public.chat_admins_id_seq OWNED BY public.chat_admins.id;


--
-- Name: chat_settings; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.chat_settings (
    chat_id bigint NOT NULL,
    blocked_words text[],
    blocked_domains text[],
    restrict_image boolean DEFAULT false,
    restrict_video boolean DEFAULT false,
    restrict_audio boolean DEFAULT false,
    restrict_file boolean DEFAULT false,
    enable_word_filter boolean DEFAULT true,
    enable_link_filter boolean DEFAULT true,
    enable_mute boolean DEFAULT false,
    enable_auto_delete boolean DEFAULT true,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.chat_settings OWNER TO maxbot;

--
-- Name: chat_stats; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.chat_stats (
    chat_id bigint NOT NULL,
    date date NOT NULL,
    word_violations bigint DEFAULT 0,
    link_violations bigint DEFAULT 0,
    image_violations bigint DEFAULT 0,
    video_violations bigint DEFAULT 0,
    audio_violations bigint DEFAULT 0,
    file_violations bigint DEFAULT 0,
    mute_count bigint DEFAULT 0
);


ALTER TABLE public.chat_stats OWNER TO maxbot;

--
-- Name: link_tokens; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.link_tokens (
    token text NOT NULL,
    user_id bigint,
    expires_at timestamp with time zone
);


ALTER TABLE public.link_tokens OWNER TO maxbot;

--
-- Name: mutes; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.mutes (
    id bigint NOT NULL,
    chat_id bigint,
    user_id bigint,
    user_name character varying(255),
    expires_at timestamp with time zone
);


ALTER TABLE public.mutes OWNER TO maxbot;

--
-- Name: mutes_id_seq; Type: SEQUENCE; Schema: public; Owner: maxbot
--

CREATE SEQUENCE public.mutes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mutes_id_seq OWNER TO maxbot;

--
-- Name: mutes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maxbot
--

ALTER SEQUENCE public.mutes_id_seq OWNED BY public.mutes.id;


--
-- Name: user_states; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.user_states (
    user_id bigint NOT NULL,
    chat_id bigint NOT NULL,
    action text NOT NULL,
    metadata text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.user_states OWNER TO maxbot;

--
-- Name: user_states_user_id_seq; Type: SEQUENCE; Schema: public; Owner: maxbot
--

CREATE SEQUENCE public.user_states_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_states_user_id_seq OWNER TO maxbot;

--
-- Name: user_states_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maxbot
--

ALTER SEQUENCE public.user_states_user_id_seq OWNED BY public.user_states.user_id;


--
-- Name: user_violations; Type: TABLE; Schema: public; Owner: maxbot
--

CREATE TABLE public.user_violations (
    id bigint NOT NULL,
    chat_id bigint NOT NULL,
    user_id bigint NOT NULL,
    violation_type character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_violations OWNER TO maxbot;

--
-- Name: user_violations_id_seq; Type: SEQUENCE; Schema: public; Owner: maxbot
--

CREATE SEQUENCE public.user_violations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_violations_id_seq OWNER TO maxbot;

--
-- Name: user_violations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: maxbot
--

ALTER SEQUENCE public.user_violations_id_seq OWNED BY public.user_violations.id;


--
-- Name: chat_admins id; Type: DEFAULT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.chat_admins ALTER COLUMN id SET DEFAULT nextval('public.chat_admins_id_seq'::regclass);


--
-- Name: mutes id; Type: DEFAULT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.mutes ALTER COLUMN id SET DEFAULT nextval('public.mutes_id_seq'::regclass);


--
-- Name: user_states user_id; Type: DEFAULT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.user_states ALTER COLUMN user_id SET DEFAULT nextval('public.user_states_user_id_seq'::regclass);


--
-- Name: user_violations id; Type: DEFAULT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.user_violations ALTER COLUMN id SET DEFAULT nextval('public.user_violations_id_seq'::regclass);


--
-- Data for Name: chat_admins; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.chat_admins (id, chat_id, user_id, created_at) FROM stdin;
1	-71182379786298	13266746	2026-04-17 16:36:20.471004+00
2	-71167999221818	13266746	2026-04-17 16:36:50.129871+00
3	-71082746978362	13266746	2026-04-17 16:37:30.752689+00
\.


--
-- Data for Name: chat_settings; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.chat_settings (chat_id, blocked_words, blocked_domains, restrict_image, restrict_video, restrict_audio, restrict_file, enable_word_filter, enable_link_filter, enable_mute, enable_auto_delete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_stats; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.chat_stats (chat_id, date, word_violations, link_violations, image_violations, video_violations, audio_violations, file_violations, mute_count) FROM stdin;
\.


--
-- Data for Name: link_tokens; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.link_tokens (token, user_id, expires_at) FROM stdin;
\.


--
-- Data for Name: mutes; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.mutes (id, chat_id, user_id, user_name, expires_at) FROM stdin;
\.


--
-- Data for Name: user_states; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.user_states (user_id, chat_id, action, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_violations; Type: TABLE DATA; Schema: public; Owner: maxbot
--

COPY public.user_violations (id, chat_id, user_id, violation_type, created_at) FROM stdin;
\.


--
-- Name: chat_admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maxbot
--

SELECT pg_catalog.setval('public.chat_admins_id_seq', 3, true);


--
-- Name: mutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maxbot
--

SELECT pg_catalog.setval('public.mutes_id_seq', 1, false);


--
-- Name: user_states_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maxbot
--

SELECT pg_catalog.setval('public.user_states_user_id_seq', 1, false);


--
-- Name: user_violations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maxbot
--

SELECT pg_catalog.setval('public.user_violations_id_seq', 1, false);


--
-- Name: chat_admins chat_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.chat_admins
    ADD CONSTRAINT chat_admins_pkey PRIMARY KEY (id);


--
-- Name: chat_settings chat_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.chat_settings
    ADD CONSTRAINT chat_settings_pkey PRIMARY KEY (chat_id);


--
-- Name: chat_stats chat_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.chat_stats
    ADD CONSTRAINT chat_stats_pkey PRIMARY KEY (chat_id, date);


--
-- Name: link_tokens link_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.link_tokens
    ADD CONSTRAINT link_tokens_pkey PRIMARY KEY (token);


--
-- Name: mutes mutes_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.mutes
    ADD CONSTRAINT mutes_pkey PRIMARY KEY (id);


--
-- Name: user_states user_states_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.user_states
    ADD CONSTRAINT user_states_pkey PRIMARY KEY (user_id);


--
-- Name: user_violations user_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: maxbot
--

ALTER TABLE ONLY public.user_violations
    ADD CONSTRAINT user_violations_pkey PRIMARY KEY (id);


--
-- Name: idx_chat_user; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE UNIQUE INDEX idx_chat_user ON public.chat_admins USING btree (chat_id, user_id);


--
-- Name: idx_link_tokens_expires_at; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE INDEX idx_link_tokens_expires_at ON public.link_tokens USING btree (expires_at);


--
-- Name: idx_link_tokens_user_id; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE INDEX idx_link_tokens_user_id ON public.link_tokens USING btree (user_id);


--
-- Name: idx_mutes_chat_id; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE INDEX idx_mutes_chat_id ON public.mutes USING btree (chat_id);


--
-- Name: idx_mutes_expires_at; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE INDEX idx_mutes_expires_at ON public.mutes USING btree (expires_at);


--
-- Name: idx_mutes_user_id; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE INDEX idx_mutes_user_id ON public.mutes USING btree (user_id);


--
-- Name: idx_user_violations_chat_user_created; Type: INDEX; Schema: public; Owner: maxbot
--

CREATE INDEX idx_user_violations_chat_user_created ON public.user_violations USING btree (chat_id, user_id, created_at);


--
-- PostgreSQL database dump complete
--

\unrestrict 2bzgTDB9UyjbrfT5zuC9qaK7xv1dzCx8VPgLxQy9ns728PZ0QNAOjsocFIbIyfw

